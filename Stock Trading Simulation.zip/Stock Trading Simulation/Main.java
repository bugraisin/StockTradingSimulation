public class Main {
    public static void main(String[] args) {
        Trader trader = new Trader();
// Sample orders
        Order order1 = new Order("AAPL", "buy", 150.0, 100, 1, "user1", true);
        Order order0 = new Order("AAPL", "sell", 150.0, 100, 2, "user21", true);
        Order order2 = new Order("GOOGL", "sell", 250.0, 50, 3, "user2", true);
        Order order3 = new Order("MSFT", "buy", 180.0, 200, 4, "user3", false);
        Order order4 = new Order("AAPL", "sell", 150.0, 50, 5, "user4", false);
        Order cancelOrder = new Order("MSFT", "Cancel", 0.0, 0, 4, "user3", false);
// Push orders to the trader
        trader.pushOrder(order1);
        trader.pushOrder(order0);
        trader.pushOrder(order2);
        trader.pushOrder(order3);
        trader.pushOrder(order4);
// Execute trades
        System.out.println("1-execute");
        trader.execute();
// Print executed orders
        trader.printExecutedOrders();
//Format: sellerUsername,buyerUsername, price, quantity
// Push cancel order to the trader
        trader.pushOrder(cancelOrder); //MSFT got cancelled
// Execute trades after cancel order
        System.out.println("2-execute");
        trader.execute();
        trader.printExecutedOrders();
        Order order6 = new Order("GOOGL", "buy", 300.0, 300, 6, "user5", false);
        trader.pushOrder(order6);
// Print updated executed orders
        System.out.println("3-execute");
        trader.execute();
        trader.printExecutedOrders(); //nothing
        trader.printOrderQueue();
//"GOOGL", "sell", 250.0, 50, 2, "user2", true
//"AAPL", "buy", 150.0, 50, 1, "user1", false
    }
}