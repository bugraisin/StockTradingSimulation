public class Order {
    private String symbol, type, ID;
    private int timestamp, quantity;
    private double price;
    private boolean flag;

    public Order(String symbol, String type, double price, int quantity,int timestamp, String ID,  boolean flag) {
        this.symbol = symbol;
        this.type = type;
        this.ID = ID;
        this.timestamp = timestamp;
        this.quantity = quantity;
        this.price = price;
        this.flag = flag;
    }

    public String getSymbol() {
        return symbol;
    }

    public void setSymbol(String symbol) {
        this.symbol = symbol;
    }

    public String getType() {
        return type;
    }

    public void setType(String type) {
        this.type = type;
    }

    public String getID() {
        return ID;
    }

    public void setID(String ID) {
        this.ID = ID;
    }

    public int getTimestamp() {
        return timestamp;
    }

    public void setTimestamp(int timestamp) {
        this.timestamp = timestamp;
    }

    public int getQuantity() {
        return quantity;
    }

    public void setQuantity(int quantity) {
        this.quantity = quantity;
    }

    public double getPrice() {
        return price;
    }

    public void setPrice(double price) {
        this.price = price;
    }

    public boolean isFlag() {
        return flag;
    }

    public void setFlag(boolean flag) {
        this.flag = flag;
    }
}
