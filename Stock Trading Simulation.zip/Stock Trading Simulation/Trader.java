import java.util.ArrayDeque;
import java.util.ArrayList;
import java.util.Queue;
public class Trader {
    private Queue<Order> orderQueue;
    private Queue<String> executedOrderQueue;
    public Trader () {
        orderQueue = new ArrayDeque<>();
        executedOrderQueue = new ArrayDeque<>();
    }

    public void pushOrder(Order order) {
        //bir cancel type push edildiğinde queueden eşdeğer timestampli obje direkt kaldırılır.
        if(order != null && !order.getType().equals("Cancel"))
            orderQueue.add(order);
        else if (order.getType().equals("Cancel"))
            cancelOrder(order);
        else
            return;
    }
    public void execute() {
        ArrayList<Order> buyOrders = new ArrayList<>();
        ArrayList<Order> sellOrders = new ArrayList<>();
        //queueyi buyOrders ve sellOrders adlı listelere koydum
        while(!orderQueue.isEmpty()) {
            Order tmp = orderQueue.poll();
            if(tmp.getType().equals("buy"))
                buyOrders.add(tmp);
            else if(tmp.getType().equals("sell"))
                sellOrders.add(tmp);
        }
        for(Order buyer : buyOrders) {
            //her loop döngüsünde quantity değerleri 0 olanları işleme girmeyeceğinden listeden silmedim ayrıca cancel değerleri zaten buyer ve seller listlerinde değil
            for(Order seller : sellOrders) {
                if(buyer.getSymbol().equals(seller.getSymbol()) && (buyer.getPrice() >= seller.getPrice()) && seller.getQuantity()!=0 && buyer.getQuantity()!=0) {
                    //eğer semboller eşleşmiyorsa ve seller yada buyer objesinin quantitysi 0 ise işleme girmiyor
                    //benefit is on buyer işlemide burada kontrol ediliyor eğer seller fiyatı buyer fiyatından fazlaysa işleme girmez
                    if(buyer.isFlag() && seller.isFlag()) {
                        //allOrNone kontrolleri ikisi için TRUE TRUE
                        if(buyer.getQuantity() == seller.getQuantity()) {
                            logExecutedOrder(buyer, seller, seller.getPrice(), seller.getQuantity());
                            buyer.setQuantity(0);
                            seller.setQuantity(0);
                        }
                    } else if(!buyer.isFlag() && seller.isFlag()) {
                        // FALSE TRUE
                        if(buyer.getQuantity() >= seller.getQuantity()) {
                            //seller allOrNone true olduğundan dolayı buyer quantity miktarı sellera eşit veya büyük olmalı
                            int buyerQuantity = buyer.getQuantity();
                            int sellerQuantity = seller.getQuantity();
                            logExecutedOrder(buyer, seller, seller.getPrice(), sellerQuantity);
                            buyer.setQuantity(buyerQuantity - sellerQuantity);
                            seller.setQuantity(0);
                        }
                    } else if(buyer.isFlag() && !seller.isFlag()) {
                        // TRUE FALSE
                        if(buyer.getQuantity() <= seller.getQuantity()) {
                            //benzer şekilde buyer allOrNone true iken seller quantity değeri eşit veya fazla olmalı
                            int buyerQuantity = buyer.getQuantity();
                            int sellerQuantity = seller.getQuantity();
                            logExecutedOrder(buyer, seller, seller.getPrice(),buyerQuantity);
                            buyer.setQuantity(0);
                            seller.setQuantity(sellerQuantity - buyerQuantity);
                        }
                    } else {
                        /* FALSE FALSE olduğu durumu 3 condition için inceledim
                        1- buyer miktarı sellerdan büyük ise sellerın bütün ürünlerini alır
                        2- buyer miktarı küçük ise sellerdaki belirli miktarda mal alır
                        3- son durumda ise eşit olma durumları ikiside başarılı bir tam satış yapar
                         */
                        int buyerQuantity = buyer.getQuantity();
                        int sellerQuantity = seller.getQuantity();
                        if (buyerQuantity > sellerQuantity) {
                            logExecutedOrder(buyer, seller, seller.getPrice(), sellerQuantity);
                            seller.setQuantity(0);
                            buyer.setQuantity(buyerQuantity - sellerQuantity);
                        }else if(buyerQuantity < sellerQuantity) {
                            logExecutedOrder(buyer, seller, seller.getPrice(), buyerQuantity);
                            buyer.setQuantity(0);
                            seller.setQuantity(sellerQuantity - buyerQuantity);
                        }else {
                            logExecutedOrder(buyer, seller, seller.getPrice(), seller.getQuantity());
                            buyer.setQuantity(0);
                            seller.setQuantity(0);
                        }
                    }
                }
            }
        }
        // çıktıda timestamp sırasına göre output verilmemiş fakat timestamp sırasına göre bir çıktı daha düzenli olur diye düşündüm
        ArrayList<Order> sortedList = new ArrayList<>();

        for(Order buyer : buyOrders) {
            if(buyer.getQuantity() != 0)
                sortedList.add(buyer);
        }
        for(Order seller : sellOrders) {
            if(seller.getQuantity() != 0)
                sortedList.add(seller);
        }
        for(int i=0; i<sortedList.size()-1; i++)
            for(int j=i+1; j<sortedList.size(); j++) {
                Order left = sortedList.get(i);
                Order right = sortedList.get(j);
                if(left.getTimestamp() > right.getTimestamp()) {
                    sortedList.set(i,right);
                    sortedList.set(j,left);
                }
            }
        orderQueue.addAll(sortedList);
    }
    public void printExecutedOrders() {
        while(!executedOrderQueue.isEmpty())
            System.out.println(executedOrderQueue.poll());
    }
    public void logExecutedOrder(Order buyOrder, Order sellOrder, double price, int quantity) {
        String str = buyOrder.getID() +", "+sellOrder.getID()+", "+price+", "+quantity;
        executedOrderQueue.add(str);
    }
    public void cancelOrder(Order order) {
        Queue<Order> tmp = new ArrayDeque<>();
        while(!orderQueue.isEmpty()) {
            if(orderQueue.element().getTimestamp() == order.getTimestamp())
                orderQueue.poll();
            else
                tmp.add(orderQueue.poll());
        }
        orderQueue = tmp;
    }
    public void printOrderQueue() {
        for(Order o : orderQueue) {
            System.out.println(o.getSymbol()+", "+o.getType()+
                    ", "+o.getPrice()+", "+o.getQuantity()+
                    ", "+ o.getTimestamp()+", "+o.getID()+
                    ", "+o.isFlag());
        }
    }
}